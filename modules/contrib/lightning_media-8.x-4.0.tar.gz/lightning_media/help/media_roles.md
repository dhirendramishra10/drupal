## Media Roles

### Media Creator

This is a limited role which grants permission to create, edit, and delete
media. It does *not* grant the permission to edit or delete media assets created
by other users, only your own.

### Media Manager

This role can create, edit, or delete all media assets created by anybody.
