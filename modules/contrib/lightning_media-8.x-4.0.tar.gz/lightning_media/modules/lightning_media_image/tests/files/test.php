<?php

/**
 * @file
 * Behold, my scary PHP file! Tremble in your boots, mortals.
 *
 * No but seriously, this is here to test that unrecognized and possibly
 * malicious file extensions are rejected by the FileUpload entity browser
 * widget.
 */
